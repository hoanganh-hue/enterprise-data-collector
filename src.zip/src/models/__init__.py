"""
Data models for Enterprise Data Collector API
Enhanced models cho thông tin doanh nghiệp với support đầy đủ các field
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from datetime import datetime
import json


@dataclass
class City:
    """Model cho tỉnh/thành phố"""
    id: int
    name: str
    slug: str
    code: Optional[str] = None
    type: Optional[str] = None  # Thành phố, Tỉnh


@dataclass
class District:
    """Model cho quận/huyện"""
    id: int
    name: str
    slug: str
    city_id: int
    code: Optional[str] = None
    type: Optional[str] = None  # Quận, Huyện, Thị xã


@dataclass
class Ward:
    """Model cho phường/xã"""
    id: int
    name: str
    slug: str
    district_id: int
    code: Optional[str] = None
    type: Optional[str] = None  # Phường, Xã, Thị trấn


@dataclass
class Industry:
    """Model cho ngành nghề kinh doanh"""
    id: int
    name: str
    slug: str
    code: Optional[str] = None
    parent_id: Optional[int] = None


@dataclass
class CompanySearchResult:
    """Model cho kết quả tìm kiếm công ty (danh sách)"""
    ma_so_thue: str
    ten_cong_ty: str
    dia_chi: str
    tinh_trang: str
    slug: str
    ngay_cap: Optional[str] = None
    nganh_nghe: Optional[str] = None


@dataclass
class CompanyDetail:
    """Model đầy đủ cho thông tin chi tiết công ty"""
    # Thông tin cơ bản
    ma_so_thue: str
    ten_cong_ty: str
    ten_giao_dich: Optional[str] = None
    ten_tieng_anh: Optional[str] = None
    
    # Người đại diện
    nguoi_dai_dien: Optional[str] = None
    chuc_vu_dai_dien: Optional[str] = None
    
    # Thông tin liên hệ  
    dia_chi: Optional[str] = None
    dien_thoai: Optional[str] = None
    fax: Optional[str] = None
    email: Optional[str] = None
    website: Optional[str] = None
    
    # Thông tin hoạt động
    tinh_trang_hoat_dong: Optional[str] = None
    ngay_cap_phep: Optional[str] = None
    ngay_hoat_dong: Optional[str] = None
    ngay_thay_doi_gan_nhat: Optional[str] = None
    
    # Thông tin kinh doanh
    nganh_nghe_kinh_doanh_chinh: Optional[str] = None
    nganh_nghe_khac: Optional[List[str]] = field(default_factory=list)
    loai_hinh_doanh_nghiep: Optional[str] = None
    
    # Thông tin tài chính
    von_dieu_le: Optional[str] = None
    von_dang_ky: Optional[str] = None
    
    # Địa lý
    tinh_thanh_pho: Optional[str] = None
    quan_huyen: Optional[str] = None
    phuong_xa: Optional[str] = None
    
    # Cơ quan quản lý
    co_quan_cap_phep: Optional[str] = None
    so_quyet_dinh: Optional[str] = None
    
    # Raw JSON data từ API
    raw_json: Dict[str, Any] = field(default_factory=dict)
    
    # Metadata
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for database storage"""
        data = {}
        for field_name, field_def in self.__dataclass_fields__.items():
            value = getattr(self, field_name)
            if isinstance(value, datetime):
                data[field_name] = value.isoformat() if value else None
            elif isinstance(value, list):
                data[field_name] = json.dumps(value, ensure_ascii=False)
            else:
                data[field_name] = value
        return data
    
    @classmethod
    def from_api_response(cls, api_data: Dict[str, Any]) -> 'CompanyDetail':
        """Tạo CompanyDetail từ API response"""
        
        # Mapping các field từ API response
        field_mapping = {
            'MaSoThue': 'ma_so_thue',
            'Title': 'ten_cong_ty',
            'TenGiaoDich': 'ten_giao_dich',
            'TenTiengAnh': 'ten_tieng_anh',
            'NguoiDaiDien': 'nguoi_dai_dien',
            'ChucVuDaiDien': 'chuc_vu_dai_dien',
            'DiaChiCongTy': 'dia_chi',
            'DienThoai': 'dien_thoai',
            'Fax': 'fax',
            'Email': 'email',
            'Website': 'website',
            'TrangThaiHoatDong': 'tinh_trang_hoat_dong',
            'NgayCap': 'ngay_cap_phep',
            'NgayHoatDong': 'ngay_hoat_dong',
            'NgayThayDoiGanNhat': 'ngay_thay_doi_gan_nhat',
            'NganhNgheKinhDoanhChinh': 'nganh_nghe_kinh_doanh_chinh',
            'LoaiHinhDoanhNghiep': 'loai_hinh_doanh_nghiep',
            'VonDieuLe': 'von_dieu_le',
            'VonDangKy': 'von_dang_ky',
            'TinhThanhPho': 'tinh_thanh_pho',
            'QuanHuyen': 'quan_huyen',
            'PhuongXa': 'phuong_xa',
            'CoQuanCapPhep': 'co_quan_cap_phep',
            'SoQuyetDinh': 'so_quyet_dinh'
        }
        
        # Convert API data to model fields
        model_data = {}
        for api_field, model_field in field_mapping.items():
            if api_field in api_data:
                model_data[model_field] = api_data[api_field]
        
        # Xử lý danh sách ngành nghề khác
        if 'NganhNgheKhac' in api_data and api_data['NganhNgheKhac']:
            if isinstance(api_data['NganhNgheKhac'], list):
                model_data['nganh_nghe_khac'] = api_data['NganhNgheKhac']
            elif isinstance(api_data['NganhNgheKhac'], str):
                model_data['nganh_nghe_khac'] = [api_data['NganhNgheKhac']]
        
        # Lưu raw JSON
        model_data['raw_json'] = api_data
        
        # Timestamp
        model_data['updated_at'] = datetime.now()
        
        return cls(**model_data)


@dataclass
class ApiResponse:
    """Generic API response wrapper"""
    success: bool
    data: Any
    message: Optional[str] = None
    total_count: Optional[int] = None
    current_page: Optional[int] = None
    total_pages: Optional[int] = None
    
    @classmethod
    def success_response(cls, data: Any, message: str = "Success") -> 'ApiResponse':
        return cls(success=True, data=data, message=message)
    
    @classmethod
    def error_response(cls, message: str) -> 'ApiResponse':
        return cls(success=False, data=None, message=message)


@dataclass
class PaginatedResponse:
    """Response với pagination support"""
    items: List[Any]
    current_page: int
    total_pages: int
    total_count: int
    page_size: int
    has_next: bool
    has_previous: bool
    
    @classmethod
    def from_api_data(cls, items: List[Any], page: int, page_size: int, total_count: int) -> 'PaginatedResponse':
        total_pages = (total_count + page_size - 1) // page_size
        return cls(
            items=items,
            current_page=page,
            total_pages=total_pages,
            total_count=total_count,
            page_size=page_size,
            has_next=page < total_pages,
            has_previous=page > 1
        )